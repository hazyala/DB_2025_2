-- Movie Sniper 무비 스나이퍼 테이블 생성문

-- User 회원 테이블
-- 1. 회원 ID 자동 증가를 위한 시퀀스 생성
CREATE SEQUENCE seq_user_id START WITH 1 INCREMENT BY 1;

-- 2. 회원(Users) 테이블 생성
CREATE TABLE Users (
    user_id       NUMBER(10)      NOT NULL,
    email         VARCHAR2(100)   NOT NULL,
    password      VARCHAR2(256)   NOT NULL,
    name          VARCHAR2(50)    NOT NULL,
    phone         VARCHAR2(20)    NOT NULL,
    payment       VARCHAR2(50),               
    created_at    TIMESTAMP       DEFAULT SYSDATE NOT NULL, 
    updated_at    TIMESTAMP,                 
    CONSTRAINT pk_users PRIMARY KEY (user_id),
    CONSTRAINT uq_users_email UNIQUE (email)
);


-- Movie 영화 테이블
-- 1. 영화 ID 자동 증가를 위한 시퀀스 생성
CREATE SEQUENCE seq_movie_id START WITH 1 INCREMENT BY 1;

-- 2. 영화(Movie) 테이블 생성
CREATE TABLE Movie (
    movie_id      NUMBER(10)      NOT NULL,
    title         VARCHAR2(200)   NOT NULL,
    genre         VARCHAR2(100)   NOT NULL,
    runtime       NUMBER(4)       NOT NULL,
    grade         VARCHAR2(20)    NOT NULL,
    release_date  DATE            NOT NULL,
    poster        VARCHAR2(500),             
    director      VARCHAR2(100),              
    cast          VARCHAR2(500),             
    end_date      DATE,                       
    synopsis      CLOB,                       
    CONSTRAINT pk_movie PRIMARY KEY (movie_id)
);

-- Theater 상영관 테이블
-- 1. 상영관 ID 자동 증가를 위한 시퀀스 생성
CREATE SEQUENCE seq_theater_id START WITH 1 INCREMENT BY 1;

-- 2. 상영관(Theater) 테이블 생성
CREATE TABLE Theater (
    theater_id    NUMBER(5)       NOT NULL,
    theater_name  VARCHAR2(100)   NOT NULL,
    location      VARCHAR2(200),              
    CONSTRAINT pk_theater PRIMARY KEY (theater_id)
);

-- PriceRule 가격 정책 테이블
-- 1. 가격 정책 ID 자동 증가를 위한 시퀀스 생성
CREATE SEQUENCE seq_rule_id START WITH 1 INCREMENT BY 1;

-- 2. 가격 정책(PriceRule) 테이블 생성
CREATE TABLE PriceRule (
    rule_id         NUMBER(5)       NOT NULL,
    seat_coef       VARCHAR2(1000)  NOT NULL, -- JSON 형식의 문자열 저장
    book_time_coef  VARCHAR2(1000)  NOT NULL, -- JSON 형식의 문자열 저장
    discount_rate   VARCHAR2(1000)  NOT NULL, -- JSON 형식의 문자열 저장
    min_limit       NUMBER(7)       NOT NULL,
    max_limit       NUMBER(7)       NOT NULL,
    created_at      TIMESTAMP       DEFAULT SYSDATE NOT NULL, 
    updated_at      TIMESTAMP,                
    CONSTRAINT pk_price_rule PRIMARY KEY (rule_id)
);

-- Screening 상영 회차 테이블
-- 1. 상영 회차 ID 자동 증가를 위한 시퀀스 생성
CREATE SEQUENCE seq_screening_id START WITH 1 INCREMENT BY 1;

-- 2. 상영 회차(Screening) 테이블 생성
CREATE TABLE Screening (
    screening_id    NUMBER(15)      NOT NULL,
    movie_id        NUMBER(10)      NOT NULL,
    theater_id      NUMBER(5)       NOT NULL,
    screen_date     DATE            NOT NULL,
    start_time      VARCHAR2(5)     NOT NULL, -- HH:MI 형식
    end_time        VARCHAR2(5)     NOT NULL, -- HH:MI 형식
    base_price      NUMBER(7)       NOT NULL,
    CONSTRAINT pk_screening PRIMARY KEY (screening_id),
    CONSTRAINT fk_scr_movie FOREIGN KEY (movie_id) REFERENCES Movie(movie_id),
    CONSTRAINT fk_scr_theater FOREIGN KEY (theater_id) REFERENCES Theater(theater_id)
);

-- TheaterSeat 상영관 배치 정보 테이블
-- 1. 좌석 ID 자동 증가를 위한 시퀀스 생성
CREATE SEQUENCE seq_seat_id START WITH 1 INCREMENT BY 1;

-- 2. 상영관 배치 정보(TheaterSeat) 테이블 생성
CREATE TABLE TheaterSeat (
    seat_id       NUMBER(10)      NOT NULL,
    theater_id    NUMBER(5)       NOT NULL,
    row_num       VARCHAR2(5)     NOT NULL,
    col_num       NUMBER(3)       NOT NULL,
    seat_code     VARCHAR2(10)    NOT NULL,
    type          VARCHAR2(20)    NOT NULL,
    grade         VARCHAR2(10)    NOT NULL,
    wheelchair    CHAR(1)         DEFAULT 'N' NOT NULL,
    CONSTRAINT pk_theater_seat PRIMARY KEY (seat_id),
    CONSTRAINT fk_ts_theater FOREIGN KEY (theater_id) REFERENCES Theater(theater_id),
    CONSTRAINT chk_ts_wheelchair CHECK (wheelchair IN ('Y', 'N')),
    CONSTRAINT chk_ts_type CHECK (type IN ('SEAT', 'SCREEN', 'AISLE', 'RAMP', 'SPEAKER', 'EXIT'))
);

-- ScreeningSeat 상영 좌석 상태 테이블
-- 1. 상영 좌석 ID 자동 증가를 위한 시퀀스 생성
CREATE SEQUENCE seq_scr_seat_id START WITH 1 INCREMENT BY 1;

-- 2. 상영 좌석 상태(ScreeningSeat) 테이블 생성
CREATE TABLE ScreeningSeat (
    screening_seat_id NUMBER(15)      NOT NULL,
    screening_id      NUMBER(15)      NOT NULL,
    seat_id           NUMBER(10)      NOT NULL,
    status            VARCHAR2(20)    NOT NULL,
    locked_at         TIMESTAMP,
    lock_expires_at   TIMESTAMP,
    CONSTRAINT pk_scr_seat PRIMARY KEY (screening_seat_id),
    CONSTRAINT fk_ss_screening FOREIGN KEY (screening_id) REFERENCES Screening(screening_id),
    CONSTRAINT fk_ss_seat FOREIGN KEY (seat_id) REFERENCES TheaterSeat(seat_id),
    CONSTRAINT chk_ss_status CHECK (status IN ('AVAILABLE', 'LOCKED', 'BOOKED'))
);

-- Reservation 예매 내역 테이블
-- 1. 예매 ID 자동 증가를 위한 시퀀스 생성
CREATE SEQUENCE seq_res_id START WITH 1 INCREMENT BY 1;

-- 2. 예매 내역(Reservation) 테이블 생성
CREATE TABLE Reservation (
    reservation_id    NUMBER(15)      NOT NULL,
    user_id           NUMBER(10)      NOT NULL,
    status            VARCHAR2(20)    NOT NULL,
    qr_code           VARCHAR2(500),              
    created_at        TIMESTAMP       DEFAULT SYSDATE NOT NULL, 
    cancelled_at      TIMESTAMP,                 
    final_price       NUMBER(8)       NOT NULL,
    discount_rate     NUMBER(3,2),                
    CONSTRAINT pk_reservation PRIMARY KEY (reservation_id),
    CONSTRAINT fk_res_user FOREIGN KEY (user_id) REFERENCES Users(user_id),
    CONSTRAINT chk_res_status CHECK (status IN ('PENDING', 'CONFIRMED', 'CANCELLED'))
);

-- ReservationSeat 예매 좌석 내역 테이블
-- 1. 예매 좌석 ID 자동 증가를 위한 시퀀스 생성
CREATE SEQUENCE seq_res_seat_id START WITH 1 INCREMENT BY 1;

-- 2. 예매 좌석 내역(ReservationSeat) 테이블 생성
CREATE TABLE ReservationSeat (
    reservation_seat_id NUMBER(15)    NOT NULL,
    reservation_id      NUMBER(15)    NOT NULL,
    screening_seat_id   NUMBER(15)    NOT NULL,
    price               NUMBER(8)     NOT NULL,
    CONSTRAINT pk_res_seat PRIMARY KEY (reservation_seat_id),
    CONSTRAINT fk_rs_reservation FOREIGN KEY (reservation_id) REFERENCES Reservation(reservation_id),
    CONSTRAINT fk_rs_scr_seat FOREIGN KEY (screening_seat_id) REFERENCES ScreeningSeat(screening_seat_id)
);

-- Payment 결제 내역 테이블
-- 1. 결제 ID 자동 증가를 위한 시퀀스 생성
CREATE SEQUENCE seq_pay_id START WITH 1 INCREMENT BY 1;

-- 2. 결제 내역(Payment) 테이블 생성
CREATE TABLE Payment (
    payment_id        NUMBER(15)      NOT NULL,
    reservation_id    NUMBER(15)      NOT NULL,
    payment_method    VARCHAR2(50)    NOT NULL, 
    status            VARCHAR2(20)    NOT NULL,
    amount            NUMBER(8)       NOT NULL,
    created_at        TIMESTAMP       DEFAULT SYSDATE NOT NULL, 
    refunded_at       TIMESTAMP,                  
    refund_amount     NUMBER(8),                  
    CONSTRAINT pk_payment PRIMARY KEY (payment_id),
    CONSTRAINT fk_pay_reservation FOREIGN KEY (reservation_id) REFERENCES Reservation(reservation_id),
    CONSTRAINT chk_pay_status CHECK (status IN ('PAID', 'REFUNDED')) 
);

-- Review 좌석 리뷰 테이블
-- 1. 리뷰 ID 자동 증가를 위한 시퀀스 생성
CREATE SEQUENCE seq_review_id START WITH 1 INCREMENT BY 1;

-- 2. 좌석 리뷰(Review) 테이블 생성
CREATE TABLE Review (
    review_id         NUMBER(15)      NOT NULL,
    user_id           NUMBER(10)      NOT NULL,
    screening_seat_id NUMBER(15)      NOT NULL,
    sight_score       NUMBER(2,1)     NOT NULL, 
    sound_score       NUMBER(2,1)     NOT NULL,
    overall_score     NUMBER(2,1)     NOT NULL,
    comments          VARCHAR2(1000),            
    created_at        TIMESTAMP       DEFAULT SYSDATE NOT NULL, 
    updated_at        TIMESTAMP,                 
    CONSTRAINT pk_review PRIMARY KEY (review_id),
    CONSTRAINT fk_review_user FOREIGN KEY (user_id) REFERENCES Users(user_id),
    CONSTRAINT fk_review_scr_seat FOREIGN KEY (screening_seat_id) REFERENCES ScreeningSeat(screening_seat_id),
  
    CONSTRAINT chk_sight_score CHECK (sight_score BETWEEN 0 AND 5),
    CONSTRAINT chk_sound_score CHECK (sound_score BETWEEN 0 AND 5),
    CONSTRAINT chk_overall_score CHECK (overall_score BETWEEN 0 AND 5)
);

--누락 제약조건 추가
-- 1. TheaterSeat: 좌석 등급은 A, B, C 중 하나여야 한다.
ALTER TABLE TheaterSeat
ADD CONSTRAINT chk_ts_grade 
CHECK (grade IN ('A', 'B', 'C'));

-- 2. ScreeningSeat: 하나의 상영 회차에 동일한 좌석 정보가 중복될 수 없다. (UNIQUE)
ALTER TABLE ScreeningSeat
ADD CONSTRAINT uq_scr_seat_unique 
UNIQUE (screening_id, seat_id);

-- 3. PriceRule : JSON 형식
ALTER TABLE PriceRule
ADD CONSTRAINT chk_json_seat CHECK (seat_coef IS JSON);

ALTER TABLE PriceRule
ADD CONSTRAINT chk_json_time CHECK (book_time_coef IS JSON);

ALTER TABLE PriceRule
ADD CONSTRAINT chk_json_disc CHECK (discount_rate IS JSON);


COMMIT;

